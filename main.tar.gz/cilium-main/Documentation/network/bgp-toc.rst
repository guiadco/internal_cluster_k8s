.. only:: not (epub or latex or html)

    WARNING: You are looking at unreleased Cilium documentation.
    Please use the official rendered version released here:
    https://docs.cilium.io

.. _bgp_root:

BGP
---

.. toctree::
   :maxdepth: 2
   :glob:

   bgp-control-plane
   lb-ipam
   bgp
   kube-router
   bird
