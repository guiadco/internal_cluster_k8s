To install Cilium on `OpenShift <https://www.openshift.com/>`_,
perform the following steps:

**Default Configuration:**

=============== =============== ==============
Datapath        IPAM            Datastore
=============== =============== ==============
Encapsulation   Cluster Pool    Kubernetes CRD
=============== =============== ==============

**Requirements:**

* OpenShift 4.x
